
package com.mycompany.javabnb.interfaces;

import com.mycompany.javabnb.UtilInmueble;
import com.mycompany.javabnb.UtilRegistro;
import java.awt.Color;
import javax.swing.ImageIcon;

/**
 * Esta clase representa interfaces Iniciales
 * @author Luna
 */
public class Inicio extends javax.swing.JFrame {


    /**
     * Crea una nueva interfaz Inicio
     */
    public Inicio() {
        initComponents();
        getContentPane().setBackground(new Color(0, 242, 220));
        ImageIcon icono = new ImageIcon("C:\\Users\\Blanquito\\Documents\\NetBeansProjects\\JavaBnB\\src\\main\\java\\com\\mycompany\\javabnb\\imagenes\\logoJava.png"); // Reemplaza "ruta/de/la/imagen.jpg" con la ruta de tu imagen
        logo.setIcon(icono);
      
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        BotonRegistro = new javax.swing.JButton();
        BotonInicio = new javax.swing.JButton();
        logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        botonAnfitrion = new javax.swing.JRadioButton();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 242, 220));

        BotonRegistro.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonRegistro.setText("Registrarse");
        BotonRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRegistroActionPerformed(evt);
            }
        });

        BotonInicio.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        BotonInicio.setText("Iniciar Sesión");
        BotonInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonInicioActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe Script", 0, 12)); // NOI18N
        jLabel1.setText("TU MEJOR ESTANCIA A UN CLICK");

        botonAnfitrion.setText("Registrarse como anfitrión");
        botonAnfitrion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAnfitrionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(botonAnfitrion))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(138, 138, 138)
                        .addComponent(BotonInicio))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(137, 137, 137)
                        .addComponent(BotonRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(92, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(125, 125, 125))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(BotonRegistro)
                .addGap(18, 18, 18)
                .addComponent(botonAnfitrion)
                .addGap(18, 18, 18)
                .addComponent(BotonInicio)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    /**
     * Es un evento, el botón registro te lleva a registrarte como anfitrión
     * @param evt inicia la interfaz de registro para anitrión
     */
    private void BotonRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRegistroActionPerformed
       if(botonAnfitrion.isSelected()){
           RegistroAnfitrion anfitrion = new RegistroAnfitrion();
           anfitrion.setVisible(true);
           
       }
       else{
           RegistroCliente cliente = new RegistroCliente();
           cliente.setVisible(true);
           
       }
       dispose();
    }//GEN-LAST:event_BotonRegistroActionPerformed

    private void botonAnfitrionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAnfitrionActionPerformed
       
    }//GEN-LAST:event_botonAnfitrionActionPerformed

    /**
     * Este evento te lleva la ventana Inicio, porque ya estás registrado
     * @param evt inicia la interfaz Inicio
     */
    private void BotonInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonInicioActionPerformed
        Login login = new Login();
        login.setVisible(true);
        dispose();
    }//GEN-LAST:event_BotonInicioActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonInicio;
    private javax.swing.JButton BotonRegistro;
    private javax.swing.JRadioButton botonAnfitrion;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables

}
