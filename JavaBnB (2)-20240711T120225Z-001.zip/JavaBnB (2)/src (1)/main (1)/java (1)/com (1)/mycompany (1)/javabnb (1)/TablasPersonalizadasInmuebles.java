
package com.mycompany.javabnb;


import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * Esta clase representa una tabla
 * @author Luna
 */
public class TablasPersonalizadasInmuebles extends AbstractTableModel {

    private String[] columnNames = {"Título", "Habitaciones", "Precio/Noche", "Huéspedes"};
    private Object[][] data;

    /**
     * Crea una nueva tabla con Inmuebles
     * @param inmuebles 
     */
    public TablasPersonalizadasInmuebles(List<Inmueble> inmuebles) {
        this.data = convertirDatosAArray(inmuebles);
    }

    /**
     * Obtiene la longitud de filas
     * @return longitud de filas
     */
    @Override
    public int getRowCount() {
        return data.length;
    }

    /**
     * Obtiene la longitud de columnas
     * @return longitud de columnas
     */
    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    /**
     * Obtiene el valor de una celda en una tabla
     * @param rowIndex
     * @param columnIndex
     * @return 
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }

    /**
     * Obtiene el nombre de una columna del objeto
     * @param column
     * @return 
     */
    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    /**
     * convierte la lista de inmuebles a un array bidimensional de objetos
     * @param inmuebles
     * @return 
     */
    // Método para convertir la lista de inmuebles a un array bidimensional de objetos
    private Object[][] convertirDatosAArray(List<Inmueble> inmuebles) {
        Object[][] datos = new Object[inmuebles.size()][4];
        for (int i = 0; i < inmuebles.size(); i++) {
            Inmueble inmueble = inmuebles.get(i);
            datos[i][0] = inmueble.getTitulo();
            datos[i][1] = Integer.toString(inmueble.getHabitaciones()); // Convertir a String
            datos[i][2] = Double.toString(inmueble.getPrecioNoche()); // Convertir a String
            datos[i][3] = Integer.toString(inmueble.getHuespedes()); // Convertir a String
        }
        return datos;
    }
    
    /**
     * Devuelve las tablas limpias, sin datos
     * @param inmuebles 
     */
     public void limpiarDatos(List<Inmueble> inmuebles) {
        data = new Object[0][0];
        fireTableDataChanged();
    }
}


    

