
package com.mycompany.javabnb;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Esta clase representa a un Inmueble
 * @author Luna
 */
public class Inmueble implements Serializable {



   //Creación de atributos
    
    private String titulo;
    private String ciudad;
    private String direccion;
    private int huespedes;
    private int habitaciones;
    private int camas;
    private int baños;
    private double precioNoche;
    private String propiedad;
    private ArrayList<String> servicios;
    private String foto; //De tipo String para almacenar la ruta del archivo.
    private double calificacion;
    private Anfitrion anfitrion;
    
    /**
     * Crea un nuevo Inmueble con sus atributos específicos
     * @param titulo
     * @param ciudad
     * @param direccion
     * @param huespedes
     * @param habitaciones
     * @param camas
     * @param baños
     * @param propiedad
     * @param servicios
     * @param foto
     * @param precioNoche
     * @param anfitrion 
     */

    public Inmueble(String titulo, String ciudad, String direccion, int huespedes, int habitaciones, int camas, int baños, String propiedad, ArrayList<String> servicios, String foto, double precioNoche, Anfitrion anfitrion) {
        this.titulo = titulo;
        this.ciudad = ciudad;
        this.direccion = direccion;
        this.huespedes = huespedes;
        this.habitaciones = habitaciones;
        this.camas = camas;
        this.baños = baños;
        this.precioNoche = precioNoche;
        this.propiedad = propiedad;
        this.servicios = servicios;
        this.foto = foto;
        this.anfitrion = anfitrion; //Cada inmueble está relacionado con un anfitrión.
    }

    /**
     * Crea un nuevo Inmueble con sus atributos específicos
     * @param titulo
     * @param ciudad
     * @param direccion
     * @param huespedes
     * @param habitaciones
     * @param camas
     * @param baños
     * @param precioNoche
     * @param propiedad
     * @param servicios
     * @param foto
     * @param calificacion
     * @param anfitrion 
     */
    
    //Este constructor es para una vez que ya están registrados 
    public Inmueble(String titulo, String ciudad, String direccion, int huespedes, int habitaciones, int camas, int baños, double precioNoche, String propiedad, ArrayList<String> servicios, String foto, double calificacion, Anfitrion anfitrion) {
        this.titulo = titulo;
        this.ciudad = ciudad;
        this.direccion = direccion;
        this.huespedes = huespedes;
        this.habitaciones = habitaciones;
        this.camas = camas;
        this.baños = baños;
        this.precioNoche = precioNoche;
        this.propiedad = propiedad;
        this.servicios = servicios;
        this.foto = foto;
        this.calificacion = calificacion;
        this.anfitrion = anfitrion;
    }
    
 
    
    /**
     * Obtiene el titulo de un Inmueble
     * @return Titulo de un Inmueble
     */

    public String getTitulo() {
        return titulo;
    }

   /**
    * Establece el Titulo de un Inmueble
    * @param titulo 
    */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Obtiene la Ciudad donde está el inmueble
     * @return La ciudad de un Inmueble
     */
    public String getCiudad() {
        return ciudad;
    }

    /**
     * Establecer la ciudad de un Inmueble
     * @param ciudad
     */
    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

 
    /**
     * Obtiene la direccion de un Inmueble
     * @return la direccion de un Inmueble
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la direccion de un Inmueble
     * @param direccion 
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene los huespedes de ese Inmueble
     * @return los huespedes de ese Inmueble
     */
    public int getHuespedes() {
        return huespedes;
    }

    /**
     * Establecer los huespedes de ese Inmueble
     * @param huespedes 
     */
    public void setHuespedes(int huespedes) {
        this.huespedes = huespedes;
    }

    /**
     * Obtiene las habitaciones de ese Inmueble
     * @return las habitaciones de ese Inmueble
     */
    public int getHabitaciones() {
        return habitaciones;
    }

    /**
     * Establece las habitaciones de ese Inmueble
     * @param habitaciones 
     */
    public void setHabitaciones(int habitaciones) {
        this.habitaciones = habitaciones;
    }

    /**
     * Obtiene las camas de ese Inmueble
     * @return las camas de ese Inmueble
     */
    public int getCamas() {
        return camas;
    }
    

    /**
     * Establece las camas de ese Inmueble
     * @param camas 
     */
    public void setCamas(int camas) {
        this.camas = camas;
    }

    /**
     * Obtiene los baños de ese Inmueble
     * @return los baños de ese Inmueble
     */
    public int getBaños() {
        return baños;
    }
    

    /**
     * Establece los baños de ese Inmueble
     * @param baños 
     */
    public void setBaños(int baños) {
        this.baños = baños;
    }

    /**
     * Establece el tipo de propiedad de ese Inmueble
     * @return obtiene el tipo de propiedad de ese Inmueble
     */
    public String getPropiedad() {
        return propiedad;
    }

    /**
     * Obtiene el tipo de propiedad de ese Inmuebñe
     * @param propiedad 
     */
    public void setPropiedad(String propiedad) {
        this.propiedad = propiedad;
    }

    /**
     * Obtiene el Precio/noche de ese Inmueble
     * @return el precio/noche de ese Inmueble
     */
    public double getPrecioNoche() {
        return precioNoche;
    }

    /**
     * Establece el Precio/noche de ese Inmueble
     * @param precioNoche 
     */
    public void setPrecioNoche(double precioNoche) {
        this.precioNoche = precioNoche;
    }

    /**
     * Obtiene la lista de servicios de ese Inmueble
     * @return la lista de servicios de ese Inmueble
     */
    public ArrayList<String> getServicios() {
        return servicios;
    }

    /**
     * Establece la lista de servicios de ese Inmueble
     * @param servicios 
     */
    public void setServicios(ArrayList<String> servicios) {
        this.servicios = servicios;
    }

    /**
     * Obtiene la foto del Inmueble
     * @return la foto del Inmueble
     */
    public String getFoto() {
        return foto;
    }

    /**
     * Establece la foto del Inmueble
     * @param foto 
     */
    public void setFoto(String foto) {
        this.foto = foto;
    }

    /**
     * Obtiene la calificacion del Inmueble
     * @return la calificación del Inmueble
     */
    public double getCalificacion() {
        return calificacion;
    }

    /**
     * Establece la calificacion del Inmueble
     * @param calificacion 
     */
    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    /**
     * Obtiene el Anfitrion del Inmueble
     * @return el Anfitrion del Inmueble
     */
    public Anfitrion getAnfitrion() {
        return anfitrion;
    }

    /**
     * Establece el Anfitrion del Inmueble
     * @param anfitrion 
     */
    public void setAnfitrion(Anfitrion anfitrion) {
      this.anfitrion = anfitrion;
    }

    /**
     * Obtiene una representacion de cadena de texto del Inmueble
     * @return cadena de texto del Inmueble
     */
    @Override
    public String toString() {
        return "Inmueble{" + "titulo=" + titulo + ", ciudad=" + ciudad + ", direccion=" + direccion + ", huespedes=" + huespedes + ", habitaciones=" + habitaciones + ", camas=" + camas + ", ba\u00f1os=" + baños + ", precioNoche=" + precioNoche + ", propiedad=" + propiedad + ", servicios=" + servicios + ", foto=" + foto +  ", anfitrion=" + anfitrion + '}';
    }

    
    
    
    
    
    
    
}
