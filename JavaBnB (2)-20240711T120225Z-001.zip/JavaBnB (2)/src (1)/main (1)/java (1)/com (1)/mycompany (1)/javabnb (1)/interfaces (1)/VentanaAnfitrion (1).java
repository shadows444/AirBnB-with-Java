
package com.mycompany.javabnb.interfaces;

import com.mycompany.javabnb.Anfitrion;
import java.awt.Color;
import javax.swing.ImageIcon;

/**
 *Esta clase representa una interfaz VentanaAnfitrion
 * @author Luna
 */
public class VentanaAnfitrion extends javax.swing.JFrame {

      private Anfitrion anfitrion;

    /**
     * Crea una nueva interfaz VentanaAnfitrion
     */
    public VentanaAnfitrion() {
        this.anfitrion = anfitrion;
        initComponents();
        getContentPane().setBackground(new Color(153, 153, 255));
        ImageIcon imagen = new ImageIcon("C:\\Users\\Blanquito\\Documents\\NetBeansProjects\\JavaBnB\\src\\main\\java\\com\\mycompany\\javabnb\\imagenes\\logoJava.png");
        logo.setIcon(imagen);
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        subirBoton = new javax.swing.JButton();
        botonAtras = new javax.swing.JButton();
        ComboBotones = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(255, 51, 51));
        jLabel1.setFont(new java.awt.Font("Verdana Pro Cond", 1, 24)); // NOI18N
        jLabel1.setText("BIENVENIDO ANFITIRÓN");

        jButton1.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        jButton1.setText("Gestionar mis apartamentos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        subirBoton.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        subirBoton.setText("Subir Apartamento");
        subirBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subirBotonActionPerformed(evt);
            }
        });

        botonAtras.setFont(new java.awt.Font("Segoe UI Emoji", 3, 12)); // NOI18N
        botonAtras.setText("Atrás");
        botonAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAtrasActionPerformed(evt);
            }
        });

        ComboBotones.setFont(new java.awt.Font("Segoe UI Historic", 3, 12)); // NOI18N
        ComboBotones.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "OPCIONES", "Mi cuenta", "Cerrar Sesión", "Atención al cliente" }));
        ComboBotones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboBotonesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(botonAtras, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(ComboBotones, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(65, 65, 65)
                .addComponent(jButton1)
                .addGap(70, 70, 70)
                .addComponent(subirBoton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ComboBotones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonAtras)
                            .addComponent(jLabel1)))
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 50, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(subirBoton))
                .addGap(135, 135, 135))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * Es un evento, cuando se pulsa el botón se genera una interfaz registrarCasa
     * @param evt genera una interfaz registrarCasa
     */
    private void subirBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subirBotonActionPerformed
        dispose();
        CasaAnfitrion registrarCasa = new CasaAnfitrion();
        registrarCasa.setVisible(true);
    }//GEN-LAST:event_subirBotonActionPerformed

    /**
     * Es un evento, cuando se pulsa el botón se genera una interfaz de Login
     * @param evt genera una interfaz de Login
     */
    private void botonAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAtrasActionPerformed
        dispose();
        Login iniSesion = new Login();
        iniSesion.setVisible(true);
    }//GEN-LAST:event_botonAtrasActionPerformed

    private void ComboBotonesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboBotonesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboBotonesActionPerformed

    /**
     * @param args the command line arguments
     */
 public static void main(String args[]) {
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ClassNotFoundException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (InstantiationException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (IllegalAccessException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (javax.swing.UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
    //</editor-fold>

    // Supongamos que tienes un objeto Anfitrion llamado "anfitrion"


    // Ahora puedes pasar este anfitrion a la ventana VentanaAnfitrion
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new VentanaAnfitrion().setVisible(true);
        }
    });
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> ComboBotones;
    private javax.swing.JButton botonAtras;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel logo;
    private javax.swing.JButton subirBoton;
    // End of variables declaration//GEN-END:variables
}
