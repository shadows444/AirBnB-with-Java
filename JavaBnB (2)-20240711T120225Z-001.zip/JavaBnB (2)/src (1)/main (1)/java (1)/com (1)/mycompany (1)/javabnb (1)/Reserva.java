
package com.mycompany.javabnb;

import java.io.Serializable;
import java.util.Date;

/**
 * Esta clase representa una reserva
 * @author Luna
 */
public class Reserva implements Serializable {
    
    //Creación de atributos
    private Inmueble reservado;
    private Particular cliente;
    private Date fechaReserva;
    private Date fechaEntrada;
    private Date fechaSalida;
    
    //Constructor
/**
 * Crea una nueva Reserva con sus específicos atributos
 * @param reservado
 * @param cliente
 * @param fechaReserva
 * @param fechaEntrada
 * @param fechaSalida 
 */
    public Reserva(Inmueble reservado, Particular cliente, Date fechaReserva, Date fechaEntrada, Date fechaSalida) {
        this.reservado = reservado;
        this.cliente = cliente;
        this.fechaReserva = fechaReserva;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
    }
    
    //Métodos

    /**
     * Obtiene el Inmueble reservado
     * @return Inmueble 
     */
    public Inmueble getReservado() {
        return reservado;
    }

    /**
     * Establece el Inmueble reservado
     * @param reservado 
     */
    public void setReservado(Inmueble reservado) {
        this.reservado = reservado;
    }

    /**
     * Obtiene el cliente particular que reserva el inmueble
     * @return el cliente que reserva el inmueble
     */
    public Particular getCliente() {
        return cliente;
    }

    /**
     * Establece el cliente particular que reserva el inmueble
     * @param cliente 
     */
    public void setCliente(Particular cliente) {
        this.cliente = cliente;
    }

    /**
     * Obtiene la fecha de reserva del Inmueble
     * @return fecha de reserva
     */
    public Date getFechaReserva() {
        return fechaReserva;
    }

    /**
     * Establece la fecha de reserva del Inmueble
     * @param fechaReserva 
     */
    public void setFechaReserva(Date fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    /**
     * Obtiene la fecha de entrada del particular al inmueble
     * @return la fecha de entrada
     */
    public Date getFechaEntrada() {
        return fechaEntrada;
    }

    /**
     * Establece la fecha de entrada del particular al inmueble
     * @param fechaEntrada 
     */
    public void setFechaEntrada(Date fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    /**
     * Obtiene la fecha de salida del particular al inmueble
     * @return la fecha de salida
     */
    public Date getFechaSalida() {
        return fechaSalida;
    }

    /**
     * Establece la fecha de salida del particular al inmueble
     * @param fechaSalida 
     */
    public void setFechaSalida(Date fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    /**
     * Obtiene una cadena de texto del objeto reserva
     * @return 
     */
    @Override
    public String toString() {
        return "Reserva{" + "reservado=" + reservado + ", cliente=" + cliente + ", fechaReserva=" + fechaReserva + ", fechaEntrada=" + fechaEntrada + ", fechaSalida=" + fechaSalida + '}';
    }
    
    
}
