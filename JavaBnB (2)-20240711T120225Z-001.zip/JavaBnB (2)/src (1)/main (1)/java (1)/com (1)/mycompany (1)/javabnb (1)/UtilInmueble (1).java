
package com.mycompany.javabnb;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.swing.JOptionPane;

/**
 * Esta clase es un Util implementa varios métodos para trabajar con Clientes (particulares y anfitrion)
 * @author Blanquito
 */
public class UtilInmueble implements Serializable{
    
    //Clase hecha para los métodos necesarios para los inmuebles
    
    //ArrayList para almacenar los inmuebles
    
      public static List<Inmueble> inmuebles = new ArrayList<>();
      public static List<Reserva> reservas = new ArrayList<>();

      //Me ha costado la vida que este código no diera error AC NO TOCAR NUNCA MÁS
      
     /**
      * Método para cargar Inmuebles desde el archivo y luego añadirlos al Array para trabar con ellos 
      */ 
     public static void cargarInmuebles() {
    try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("InmuebleData.txt"))) {
        inmuebles.clear(); // Limpiar la lista antes de cargar los nuevos inmuebles
        Object obj;
        while (true) {
            try {
                obj = objectInputStream.readObject();
                if (obj instanceof Inmueble) {
                    Inmueble inmueble = (Inmueble) obj;
                    inmuebles.add(inmueble);
                }
            } catch (EOFException e) {
                // Se alcanzó el final del archivo
                break;
            }
        }
        System.out.println("Datos de inmuebles cargados correctamente.");
    } catch (IOException | ClassNotFoundException e) {
        System.err.println("Error al cargar los inmuebles desde el archivo: " + e.getMessage());
    } finally {
        
        
    }
}


     /**
      * Método para guarda los inmuebles que están en el Array una vez que hayan sido registrados
      */

    // Método para guardar datos de inmuebles en un archivo sin sobrescribir los datos existentes
    public static void guardarInmuebles() {
    try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("InmuebleData.txt"))) {
        for (Inmueble inmueble : inmuebles) {
            objectOutputStream.writeObject(inmueble);
        }
        JOptionPane.showMessageDialog(null, "Se han guardado los inmuebles correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        System.err.println("Error al guardar los inmuebles en el archivo: " + e.getMessage());
        e.printStackTrace();
    }
}





    //Creados los métodos para guardar los inmuebles, creamos métodos para las busquedas
    
    //Método para buscar un piso en una ciudad (mediante Streams) y habiendo cargado los datos 
    //desde el archivo al ArrayList se realizará la busqueda accediendo a la ciudad del inmueble.
    
    //lOS STREAMS LO MEJOR DEL MUNDO (EL AÑO PASADO USE MAZO DE LINEAS PARA UNA BUSQUEDA)
    
    /**
     * Obtiene los Inmuebles que hay registrados por ciudad, es un método de busqueda
     * @param ciudad
     * @return Inmuebles que están resgitrados en una ciudad buscada
     */
    public static List<Inmueble> buscarInmueblePorCiudad(String ciudad){
                return inmuebles.stream()
                .filter(inmueble -> inmueble.getCiudad().equalsIgnoreCase(ciudad))
                .collect(Collectors.toList());
    }

 
    //Creamos un método para guardar reservas en el archivo
    
    /**
     * Método para guardar las reservas en su popio archivo
     */
       public static void guardarReservas() {
    try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("ReservasData.txt"))) {
        for (Reserva reserva : reservas) {
            objectOutputStream.writeObject(reserva); // Aquí deberías escribir solo la reserva actual
        }
        JOptionPane.showMessageDialog(null, "Se han guardado las reservas correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        System.err.println("Error al guardar las reservas en el archivo: " + e.getMessage());
        e.printStackTrace();
    }
}
       //Creación de un método para cargar Reservas
       
    /**
     * Método para cargar las reservas desde el archivo al array
     */   
    public static void cargarReservas() {
    reservas.clear(); // Limpiar la lista antes de cargar los nuevos inmuebles
    try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("ReservasData.txt"))) {
        Object obj;
        while (true) {
            try {
                obj = objectInputStream.readObject();
                if (obj instanceof Reserva) {
                    Reserva reserva = (Reserva) obj;
                    reservas.add(reserva);
                }
            } catch (EOFException e) {
                // Se alcanzó el final del archivo
                break;
            }
        }
        System.out.println("Datos de reservas cargados correctamente.");
    } catch (IOException | ClassNotFoundException e) {
        System.err.println("Error al cargar los inmuebles desde el archivo: " + e.getMessage());
    }
}
            
 //Método para no permitir el alquiler de ese inmueble si ya está cogido en esa fecha      

    /**
     * Método de filtración, comprueba que no haya inmuebles reservados en una fecha que se quiere
     * @param tituloInmueble
     * @param fechaInicio
     * @param fechaSalida
     * @return mensajes sobre si la reserva que se quiere hacer es válida
     */
public static boolean inmuebleDisponible(String tituloInmueble, Date fechaInicio, Date fechaSalida) {
    cargarInmuebles();
    cargarReservas(); // Cargar inmuebles si aún no se han cargado
  
    // Verificar si el título del inmueble no se encuentra en la lista de inmuebles
    boolean inmuebleNoEncontrado = true;
    for (Inmueble inmueble : inmuebles) {
        if (inmueble.getTitulo().equals(tituloInmueble)) {
            inmuebleNoEncontrado = false;
            break;
        }
    }
    // Si el título del inmueble no se encuentra, retornamos true
    if (inmuebleNoEncontrado) {
        return true;
    }

    for (Inmueble inmueble : inmuebles) {
        if (inmueble.getTitulo().equals(tituloInmueble)) {
            // Si el título del inmueble coincide, comprobamos disponibilidad
            boolean inmuebleDisponible = true;
            for (Reserva reserva : reservas) {
                if (reserva.getReservado().getTitulo().equals(tituloInmueble) &&
                        (reserva.getFechaEntrada().compareTo(fechaSalida) < 0) &&
                        (reserva.getFechaSalida().compareTo(fechaInicio) > 0)) {
               
                    inmuebleDisponible = false;
                    break;
                }
            }
            // Agrega una impresión para verificar si el inmueble está disponible o no
            System.out.println("Inmueble '" + tituloInmueble + "' disponible: " + inmuebleDisponible);
            
            // Si el inmueble está disponible, retornamos true
            if (inmuebleDisponible) {
                return true;
            }
        }
    }

    return false;
 }
}


            
            
            
            
            
   

            
            
            
            
            
            
            
            
           
            

    
    

