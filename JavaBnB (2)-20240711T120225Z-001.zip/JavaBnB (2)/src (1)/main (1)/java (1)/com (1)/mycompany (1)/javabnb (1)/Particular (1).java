
package com.mycompany.javabnb;

import java.util.Date;
import java.util.Objects;

/**
 * Representa un Cliente Particular
 * @author Luna
 */
public class Particular extends Cliente{
    
    //Creación de atributos privados propios de Particular
    
    private long numTarjeta;
    private Date fechaCad;
    private boolean VIP;

    /**
     * Crea un nuevo Particular con los atributos específicos
     * @param nombre
     * @param DNI
     * @param telefono
     * @param correo
     * @param clave
     * @param numTarjeta
     * @param fechaCad
     * @param VIP 
     */
    public Particular(String nombre, String DNI, int telefono, String correo, String clave,long numTarjeta,Date fechaCad, boolean VIP) {
        super(nombre, DNI, telefono, correo, clave);
        this.numTarjeta = numTarjeta;
        this.fechaCad = fechaCad;
        this.VIP = VIP;
    }
    
    //Creación de los métodos get y set

    /**
     * Obtiene el Numero de la tarjeta del Particular
     * @return Numero de la tarjeta
     */
    public long getNumTarjeta() {
        return numTarjeta;
    }

    /**
     * Establece el Numero de la tarjeta del Particular
     * @param numTarjeta 
     */
    public void setNumTarjeta(long numTarjeta) {
        this.numTarjeta = numTarjeta;
    }

    /**
     * Obtiene la fecha de caducidad de la tarjeta del Particular
     * @return la fecha de caducidad de la tarjeta
     */
    public Date getFechaCad() {
        return fechaCad;
    }

    /**
     * Establece la fecha de caducidad de la tarjeta del Particular
     * @param fechaCad 
     */
    public void setFechaCad(Date fechaCad) {
        this.fechaCad = fechaCad;
    }

    /**
     * Obtiene si es VIP el Particular
     * @return 
     */
    public boolean isVIP() {
        return VIP;
    }

    /**
     * Establece si es VIP el Particular
     * @param VIP 
     */
    public void setVIP(boolean VIP) {
        this.VIP = VIP;
    }

    /**
     * Determina la ubicación del objeto
     * @return la ubiación del objeto
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 29 * hash + (int) (this.numTarjeta ^ (this.numTarjeta >>> 32));
        hash = 29 * hash + Objects.hashCode(this.fechaCad);
        hash = 29 * hash + (this.VIP ? 1 : 0);
        return hash;
    }

    /**
     * Compara el objeto particular con otro objeto
     * @param obj
     * @return la comparación con el otro objeto
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Particular other = (Particular) obj;
        if (this.numTarjeta != other.numTarjeta) {
            return false;
        }
        if (this.VIP != other.VIP) {
            return false;
        }
        return Objects.equals(this.fechaCad, other.fechaCad);
    }
    
    
    
    
    
    //Creación del método ToString()

    /**
     * Obtiene una cadena de texto del objeto particular
     * @return 
     */
    @Override
    public String toString() {
        return "Particular{" + "numTarjeta=" + numTarjeta + ", fechaCad=" + fechaCad + ", VIP=" + VIP + '}';
    }
    
    
    
    
}
