package com.mycompany.javabnb;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileInputStream;
 import javax.swing.JOptionPane;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//Esta clase contiene todos los Utils de login, guardar datos y verificar esos datos

/**
 * Clase Util para métodos de tipo Login de clientes(particulares, anfitriones)
 * @author Blanquito
 */
public class UtilRegistro implements Serializable{
    //Creación de ArrayList static de Particulares y Anfitriones 
    
    //ArrayList para anfitriones
  public static List<Anfitrion> anfitriones  = new ArrayList<>();
  //ArrayList para particulares
  public static List<Particular> particulares = new ArrayList<>();
  
  /**
   * Método para guardar los anfitriones en su archivo
   */
   public static void guardarAnfitriones() {
    try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("AnfitrionData.txt"))) {
        for (Anfitrion anfitrion : anfitriones) {
            objectOutputStream.writeObject(anfitrion);
        }
        // Muestra un cuadro de diálogo con el mensaje "Hecho"
        JOptionPane.showMessageDialog(null, "Se ha registrado correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        System.err.println("Error al guardar los anfitriones en el archivo: " + e.getMessage());
    }
}

   /**
    * Método para guardar particulares en su respectivo archivo
    */
public static void guardarParticulares() {
    try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("ParticularData.txt"))) {
        for (Particular particular : particulares) {
            objectOutputStream.writeObject(particular);
        }
        // Muestra un cuadro de diálogo con el mensaje "Hecho"
        JOptionPane.showMessageDialog(null, "Se ha registrado correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);
    } catch (IOException e) {
        System.err.println("Error al guardar los particulares en el archivo: " + e.getMessage());
    }
}

/**
 * Método para cargar los anfitriones del archivo al array
 */
public static void cargarAnfitriones() {
    anfitriones.clear(); // Limpiar la lista antes de cargar
    try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("AnfitrionData.txt"))) {
        while (true) {
            try {
                Anfitrion anfitrion = (Anfitrion) objectInputStream.readObject();
                anfitriones.add(anfitrion);
            } catch (EOFException e) {
                // Se alcanzó el final del archivo
                break;
            }
        }
        System.out.println("Datos de anfitriones cargados correctamente.");
    } catch (IOException | ClassNotFoundException e) {
        System.err.println("Error al cargar los anfitriones desde el archivo: " + e.getMessage());
    }
}

/**
 * Método para cargar particulares del archivo al array
 */
public static void cargarParticulares() {
    particulares.clear(); // Limpiar la lista antes de cargar
    try (ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("ParticularData.txt"))) {
        while (true) {
            try {
                Particular particular = (Particular) objectInputStream.readObject();
                particulares.add(particular);
            } catch (EOFException e) {
                // Se alcanzó el final del archivo
                break;
            }
        }
        System.out.println("Datos de particulares cargados correctamente.");
    } catch (IOException | ClassNotFoundException e) {
        System.err.println("Error al cargar los particulares desde el archivo: " + e.getMessage());
    }
}


   

   //Una vez que tenemos los datos en el archivo, debemos hacer las excepciones a la hora de registrarse
   
   //Método para verificar si un correo ya existe en el archivo Particular
   
/**
 * Método para verificar si el correo está registrado en Particulares, si existe no permite que se registre con ese correo
 * @param correo
 * @return Mensaje de información sobre si puedes usar ese correo o no
 */
    public static boolean correoExiste(String correo) {
        try (BufferedReader reader = new BufferedReader(new FileReader("ParticularData.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(correo)) {
                    JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese correo.", "Correo Existente", JOptionPane.WARNING_MESSAGE);
                    return true; // Se encontró el correo en el archivo
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
        return false; // El correo no se encontró en el archivo
    }
   
    //Método para verificar si un correo ya existe en el archivo Anfitrion
    
    /**
     * Método para verifica si existe un correo en Anfitriones, si existe no permite registrase con ese correo
     * @param correo
     * @return Mensaje de información si puedes o no rsgitarte con ese correo
     */
     public static boolean correoExisteAnfit(String correo) {
        try (BufferedReader reader = new BufferedReader(new FileReader("AnfitrionData.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(correo)) {
                    JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese correo.", "Correo Existente", JOptionPane.WARNING_MESSAGE);
                    return true; // Se encontró el correo en el archivo
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
        return false; // El correo no se encontró en el archivo
    }
     
    //Hacemos lo mismo con el DNI y con Particulares
     /**
      * Método para verificar si el DNI no está ya regitrado en particulares, si está no permite el resgitro con ese DNI
      * @param dni
      * @return Obtiene un mensaje de error en caso de no poder
      */
      public static boolean DNIExiste(String dni) {
        try (BufferedReader reader = new BufferedReader(new FileReader("ParticularData.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(dni)) {
                    JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese DNI.", "DNI Existente", JOptionPane.WARNING_MESSAGE);
                    return true; // Se encontró el dni en el archivo
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
        return false; // El dni no se encontró en el archivo
    }
      
      //Comprobación DNI Anfitrion 
       /**
      * Método para verificar si el DNI no está ya regitrado en anfitriones, si está no permite el resgitro con ese DNI
      * @param dni
      * @return Obtiene un mensaje de error en caso de no poder
      */
       public static boolean DNIExisteAnfi(String dni) {
        try (BufferedReader reader = new BufferedReader(new FileReader("AnfitrionData.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.contains(dni)) {
                    JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese DNI.", "DNI Existente", JOptionPane.WARNING_MESSAGE);
                    return true; // Se encontró el dni en el archivo
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
        }
        return false; // El dni no se encontró en el archivo
    }
       
       //Método para verificar si el correo y la contraseña son los que pone el usuario
       /**
        * Método para verificar si el correo y contraseña son válidos en Particulares
        * @param correo
        * @param contraseña
        * @return En caso de ser las credenciales incorrectas salta un mensaje
        */
public static boolean LoginComprobarParti(String correo, String contraseña) {
    boolean find = false;
    try (BufferedReader reader = new BufferedReader(new FileReader("ParticularData.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.contains(correo) && line.contains(contraseña)) {
                JOptionPane.showMessageDialog(null, "Bienvenido Cliente", "Cliente", JOptionPane.WARNING_MESSAGE);
                find = true;
                break; // Se encontró el usuario en el archivo, por lo tanto, no es necesario seguir leyendo
            }
        }
    } catch (IOException e) {
        System.err.println("Error al leer el archivo: " + e.getMessage());
    }

    return find;
}

  /**
        * Método para verificar si el correo y contraseña son válidos en Anfitriones
        * @param correo
        * @param contraseña
        * @return En caso de ser las credenciales incorrectas salta un mensaje
        */
public static boolean LoginComprobarAnfi(String correo, String contraseña) {
    boolean find = false;
    try (BufferedReader reader = new BufferedReader(new FileReader("AnfitrionData.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            if (line.contains(correo) && line.contains(contraseña)) {
                JOptionPane.showMessageDialog(null, "Bienvenido Anfitrión", "Anfitrión", JOptionPane.WARNING_MESSAGE);
                find = true;
                break; // Se encontró el usuario en el archivo
            }
        }
    } catch (IOException e) {
        System.err.println("Error al leer el archivo: " + e.getMessage());
    }
    
    return find;
 }

//Estos métodos están hechos para poder recuperar desde el archivo seralizado los datos tanto de anfitriones como de particulares a través del Login.

/**
 * Una vez entras exitosamente como anfitrión este método recupera tu instancia y por tanto tus datos
 * @param correo
 * @return instancia de Anfitrion perteneciente a tu correo y contraseña
 */
public static Anfitrion obtenerAnfitrionPorCorreo(String correo) {
    cargarAnfitriones(); // Cargar los datos de anfitriones desde el archivo
    for (Anfitrion anfitrion : anfitriones) {
        if (anfitrion.getCorreo().equals(correo)) {
            return anfitrion; // Devolver el anfitrión cuyo correo coincide
        }
    }
    return null; // Si no se encuentra ningún anfitrión con ese correo, devolver null
}

/**
 * Una vez entras exitosamente como particular este método recupera tu instancia y por tanto tus datos
 * @param correo
 * @return instancia de particular perteneciente a tu correo y contraseña
 */
public static Particular obtenerParticularPorCorreo(String correo) {
    cargarParticulares(); // Cargar los datos de anfitriones desde el archivo
    for (Particular particular : particulares) {
        if (particular.getCorreo().equals(correo)) {
            return particular; // Devolver el anfitrión cuyo correo coincide
        }
    }
    return null; // Si no se encuentra ningún anfitrión con ese correo, devolver null
}

}     
           
    

