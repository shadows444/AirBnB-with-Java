
package com.mycompany.javabnb;

import java.util.Date;
import java.util.Objects;

/**
 * Esta clase representa a un Anfitrión
 * @author Luna
 */
public class Anfitrion extends Cliente{
    
    //Creación de los atributos privados propios de Anfitrion
    
    private Date fechaRegistro;
    boolean SuperAnfi;
    
    /**
     * Crea un nuevo empleado
     * @param nombre
     * @param DNI
     * @param telefono
     * @param correo
     * @param clave
     * @param fechaRegistro
     * @param SuperAnfi 
     */
    

    public Anfitrion(String nombre, String DNI, int telefono, String correo, String clave,Date fechaRegistro,boolean SuperAnfi) {
        super(nombre, DNI, telefono, correo, clave);
        this.fechaRegistro = fechaRegistro;
        this.SuperAnfi = SuperAnfi;
    }
    
    
    
    //Creación de los métodos get y set

    
    /**
     * 
     * @return fechaRegistro
     */
    public Date getFechaRegistro() {
        return fechaRegistro;
    }

    /**Establece la fecha de Registro
     * 
     * @param fechaRegistro 
     */
    public void setFechaRegistro(Date fechaRegistro) {
        Date fechaActual = new Date();
        this.fechaRegistro = fechaActual;
    }

    /**
     * Obtiene si es SuperAnfitrion 
     * @return boolean
     */
    public boolean isSuperAnfi() {
        return SuperAnfi;
    }

    /**
     * Establece si es SuperAnfitrion
     * @param SuperAnfi 
     */
    public void setSuperAnfi(boolean SuperAnfi) {
        this.SuperAnfi = SuperAnfi;
    }

    /**
     * Devuelve la ubicación de un objeto en una tabla hash
     * @return 
     */
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.fechaRegistro);
        hash = 97 * hash + (this.SuperAnfi ? 1 : 0);
        return hash;
    }

    /**
     * Compara el objeto actual con otro objeto
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Anfitrion other = (Anfitrion) obj;
        if (this.SuperAnfi != other.SuperAnfi) {
            return false;
        }
        return Objects.equals(this.fechaRegistro, other.fechaRegistro);
    }
    
    
    
   /**
    * 
    * @return 
    */

    @Override
 public String toString() {
    return "Anfitrión{" +
            "nombre='" + getNombre() + '\'' +
            ", DNI='" + getDNI() + '\'' +
            ", telefono=" + getTelefono() +
            ", correo='" + getCorreo() + '\'' +
            ", clave='" + getClave() + '\'' +
            ", fechaRegistro=" + fechaRegistro +
            ", SuperAnfi=" + SuperAnfi +
            '}';
 }

    
  
    
    
}
