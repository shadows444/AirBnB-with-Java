
package com.mycompany.javabnb;

import java.io.Serializable;
import java.util.Objects;

/**
 * Esta clase representa un cliente
 * @author Luna
 */


//Al ser clase padre con poner aqui el serializable vale
public class Cliente implements Serializable{
    
    //Creación de atributos
    private String nombre;
    private String DNI;
    private int telefono;
    private String correo;
    private String clave;
    
    //Creación del constructor.

    public Cliente(String nombre, String DNI, int telefono, String correo, String clave) {
        this.nombre = nombre;
        this.DNI = DNI;
        this.telefono = telefono;
        this.correo = correo;
        this.clave = clave;
    }
    
    //Creación de los métodos get y set

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public int getTelefono() {
        return telefono;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 97 * hash + Objects.hashCode(this.nombre);
        hash = 97 * hash + Objects.hashCode(this.DNI);
        hash = 97 * hash + this.telefono;
        hash = 97 * hash + Objects.hashCode(this.correo);
        hash = 97 * hash + Objects.hashCode(this.clave);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Cliente other = (Cliente) obj;
        if (this.telefono != other.telefono) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.DNI, other.DNI)) {
            return false;
        }
        if (!Objects.equals(this.correo, other.correo)) {
            return false;
        }
        return Objects.equals(this.clave, other.clave);
    }

   
    
    
    
    //Creación del método ToString()

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", DNI=" + DNI + ", telefono=" + telefono + ", correo=" + correo + ", clave=" + clave + '}';
    }
    
    
}
