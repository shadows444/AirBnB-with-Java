
package com.mycompany.javabnb;

import com.mycompany.javabnb.interfaces.Inicio;



public class JavaBnB {

    /**
     * Inicia la aplicación 
     * @param args 
     */
    public static void main(String[] args) {
    
        
        Inicio ini = new Inicio();
        ini.setVisible(true);
        
       
        
    }
}
