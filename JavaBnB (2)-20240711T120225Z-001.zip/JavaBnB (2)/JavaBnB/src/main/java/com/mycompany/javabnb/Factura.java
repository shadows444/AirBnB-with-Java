
package com.mycompany.javabnb;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Factura implements Serializable {
    
    //Creación de atributos
    private String nombreParticular;
    private String tituloInmueble;
    private double precioNoche;
    private Date fechaReserva;
    private Date fechaEntrada;
    private Date fechaSalida;
    
    //Creación del constructor

      public Factura(String nombreParticular, String tituloInmueble, double precioNoche, Date fechaReserva, Date fechaEntrada, Date fechaSalida) {
        this.nombreParticular = nombreParticular;
        this.tituloInmueble = tituloInmueble;
        this.precioNoche = precioNoche;
        this.fechaReserva = fechaReserva;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
        
        generarArchivoFactura();
    }
    
    // Método para generar el archivo de la factura
    private void generarArchivoFactura() {
    SimpleDateFormat sdfArchivo = new SimpleDateFormat("yyyyMMdd_HHmmss"); // Formato de fecha y hora para el nombre del archivo
    SimpleDateFormat sdfContenido = new SimpleDateFormat("dd/MM/yyyy"); // Formato de fecha para el contenido de la factura
    
    String nombreArchivo = "Factura_" + sdfArchivo.format(fechaReserva) + ".txt";
    String rutaArchivo = "C:\\Users\\Blanquito\\Desktop\\Facturas\\" + nombreArchivo;

    try {
        // Crear el directorio Facturas si no existe
        File dirFacturas = new File("C:\\Users\\Blanquito\\Desktop\\Facturas");
        if (!dirFacturas.exists()) {
            dirFacturas.mkdir();
        }

        // Crear el archivo de la factura
        FileWriter fw = new FileWriter(rutaArchivo);
        BufferedWriter bw = new BufferedWriter(fw);

        // Escribir el contenido de la factura
        bw.write("***************************************");
        bw.newLine();
        bw.write("            FACTURA DE RESERVA         ");
        bw.newLine();
        bw.write("***************************************");
        bw.newLine();
        bw.newLine();
        bw.write("Nombre del Particular: " + nombreParticular);
        bw.newLine();
        bw.write("Título del Inmueble: " + tituloInmueble);
        bw.newLine();
        bw.write("Precio por Noche: " + precioNoche);
        bw.newLine();
        bw.write("Fecha de Reserva: " + sdfContenido.format(fechaReserva));
        bw.newLine();
        bw.write("Fecha de Entrada: " + sdfContenido.format(fechaEntrada));
        bw.newLine();
        bw.write("Fecha de Salida: " + sdfContenido.format(fechaSalida));

        // Cerrar el archivo
        bw.close();

        System.out.println("Factura generada correctamente: " + nombreArchivo);
    } catch (IOException e) {
        System.out.println("Error al generar la factura: " + e.getMessage());
    }
 }
}