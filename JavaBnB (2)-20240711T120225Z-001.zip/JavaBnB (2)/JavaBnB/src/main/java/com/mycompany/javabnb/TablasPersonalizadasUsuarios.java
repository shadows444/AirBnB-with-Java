package com.mycompany.javabnb;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 * Respresenta un objeto tabla para todo tipo de usuarios
 * @author Blanquito
 */
public class TablasPersonalizadasUsuarios extends AbstractTableModel {
    private String[] columnNames = {"Nombre", "DNI", "Correo", "Teléfono"};
    private Object[][] data;

    /**
     * Crea objetos tablas para usuarios
     * @param particulares
     * @param anfitriones 
     */
    public TablasPersonalizadasUsuarios(List<Particular> particulares, List<Anfitrion> anfitriones) {
        this.data = convertirDatosAArray(particulares, anfitriones);
    }

    /**
     * Retorna la cantidad de filas
     * @return 
     */
    @Override
    public int getRowCount() {
        return data.length;
    }

    /**
     * Retorna la cantidad de columnas
     * @return 
     */
    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    /**
     * retorna el nombre de las columnas
     * @param column
     * @return 
     */
    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    /**
     * retorna y establece los valores que habrá en cada columna
     * @param rowIndex
     * @param columnIndex
     * @return 
     */
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }
    
    
    
    /**
     * Convierte los valores en un Array bidimensional
     * @param particulares
     * @param anfitriones
     * @return 
     */
    private Object[][] convertirDatosAArray(List<Particular> particulares, List<Anfitrion> anfitriones) {
    int totalFilas = particulares.size() + anfitriones.size();
    Object[][] datos = new Object[totalFilas][columnNames.length];

    int fila = 0;
    for (Particular particular : particulares) {
        datos[fila][0] = particular.getNombre();
        datos[fila][1] = particular.getDNI();
        datos[fila][2] = particular.getCorreo();
        datos[fila][3] = particular.getTelefono();
        fila++;
    }

    for (Anfitrion anfitrion : anfitriones) {
        datos[fila][0] = anfitrion.getNombre();
        datos[fila][1] = anfitrion.getDNI();
        datos[fila][2] = anfitrion.getCorreo();
        datos[fila][3] = anfitrion.getTelefono();
        fila++;
    }

    return datos;
}

}


 

    

