
package com.mycompany.javabnb.interfaces;

import com.mycompany.javabnb.Anfitrion;
import java.awt.Color;
import javax.swing.ImageIcon;

/**
 *Esta clase representa una interfaz VentanaAnfitrion
 * @author Luna
 */
public class VentanaAnfitrion extends javax.swing.JFrame {

      private Anfitrion anfitrion;

    /**
     * Crea una nueva interfaz VentanaAnfitrion
     */
    public VentanaAnfitrion() {
        this.anfitrion = anfitrion;
        initComponents();
        getContentPane().setBackground(new Color(153, 153, 255));
        ImageIcon icono = new ImageIcon("C:\\Users\\Blanquito\\Desktop\\JavaBnB\\src\\main\\java\\com\\mycompany\\javabnb\\imagenes\\logoJava.png"); // Reemplaza "ruta/de/la/imagen.jpg" con la ruta de tu imagen
        logo.setIcon(icono);
         
    }
 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        subirBoton = new javax.swing.JButton();
        botonAtras = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(255, 51, 51));
        jLabel1.setFont(new java.awt.Font("Verdana Pro Cond", 1, 24)); // NOI18N
        jLabel1.setText("BIENVENIDO ANFITIRÓN");

        subirBoton.setFont(new java.awt.Font("Segoe UI Light", 1, 12)); // NOI18N
        subirBoton.setText("Subir Apartamento");
        subirBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                subirBotonActionPerformed(evt);
            }
        });

        botonAtras.setFont(new java.awt.Font("Segoe UI Emoji", 3, 12)); // NOI18N
        botonAtras.setText("Atrás");
        botonAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAtrasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(167, 167, 167)
                        .addComponent(subirBoton))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(botonAtras, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(botonAtras)
                            .addComponent(jLabel1))
                        .addGap(32, 32, 32)
                        .addComponent(subirBoton))
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(198, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Es un evento, cuando se pulsa el botón se genera una interfaz registrarCasa
     * @param evt genera una interfaz registrarCasa
     */
    private void subirBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subirBotonActionPerformed
        dispose();
        CasaAnfitrion registrarCasa = new CasaAnfitrion();
        registrarCasa.setVisible(true);
        
    }//GEN-LAST:event_subirBotonActionPerformed

    /**
     * Es un evento, cuando se pulsa el botón se genera una interfaz de Login
     * @param evt genera una interfaz de Login
     */
    private void botonAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAtrasActionPerformed
        dispose();
        Login iniSesion = new Login();
        iniSesion.setVisible(true);
    }//GEN-LAST:event_botonAtrasActionPerformed

    /**
     * @param args the command line arguments
     */
 public static void main(String args[]) {
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ClassNotFoundException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (InstantiationException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (IllegalAccessException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    } catch (javax.swing.UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(VentanaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
    //</editor-fold>

    // Supongamos que tienes un objeto Anfitrion llamado "anfitrion"


    // Ahora puedes pasar este anfitrion a la ventana VentanaAnfitrion
    java.awt.EventQueue.invokeLater(new Runnable() {
        public void run() {
            new VentanaAnfitrion().setVisible(true);
        }
    });
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAtras;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel logo;
    private javax.swing.JButton subirBoton;
    // End of variables declaration//GEN-END:variables
}
