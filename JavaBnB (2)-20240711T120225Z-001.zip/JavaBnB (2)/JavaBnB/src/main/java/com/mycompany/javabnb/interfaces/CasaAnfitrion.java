
package com.mycompany.javabnb.interfaces;

import com.mycompany.javabnb.Anfitrion;
import com.mycompany.javabnb.Inmueble;
import com.mycompany.javabnb.UtilInmueble;
import static com.mycompany.javabnb.UtilInmueble.inmuebles;
import java.awt.Color;
import java.awt.Image;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import java.io.File;
import java.util.ArrayList;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;


public class CasaAnfitrion extends javax.swing.JFrame {

       private ButtonGroup group;
       private String rutaFoto;
       VentanaAnfitrion vueltaIni = new VentanaAnfitrion();
    public CasaAnfitrion() {
        initComponents();
        getContentPane().setBackground(new Color(255, 204, 255));
        ImageIcon icono = new ImageIcon("C:\\Users\\Blanquito\\Desktop\\JavaBnB\\src\\main\\java\\com\\mycompany\\javabnb\\imagenes\\logoJava.png"); // Reemplaza "ruta/de/la/imagen.jpg" con la ruta de tu imagen
        logo.setIcon(icono);
        group = new ButtonGroup(); // Inicializar el ButtonGroup en el constructor
        
        // Agregar los botones al ButtonGroup
        group.add(botonCasa);
        group.add(botonApartamento);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        logo = new javax.swing.JLabel();
        huecoTitulo = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        huecoDireccion = new javax.swing.JTextField();
        huespedes = new javax.swing.JLabel();
        huecoHuespedes = new javax.swing.JTextField();
        huespedes1 = new javax.swing.JLabel();
        huecoHabitaciones = new javax.swing.JTextField();
        huespedes2 = new javax.swing.JLabel();
        huecoCamas = new javax.swing.JTextField();
        huespedes3 = new javax.swing.JLabel();
        huecoBaños = new javax.swing.JTextField();
        botonCasa = new javax.swing.JRadioButton();
        botonApartamento = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        huecoPrecio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        huecoServicios = new javax.swing.JTextField();
        botonSubirFoto = new javax.swing.JButton();
        huecoFoto = new javax.swing.JLabel();
        botonRegistro = new javax.swing.JButton();
        botonAtras = new javax.swing.JButton();
        huecoCiudad = new javax.swing.JTextField();
        huespedes4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 3, 18)); // NOI18N
        jLabel1.setText("REGISTRAR APARTAMENTO");

        huecoTitulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                huecoTituloActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel2.setText("Título/Breve descripción:");

        jLabel3.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel3.setText("Dirección:");

        huecoDireccion.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N

        huespedes.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        huespedes.setText("nº huespedes:");

        huecoHuespedes.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N

        huespedes1.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        huespedes1.setText("nº habitaciones:");

        huecoHabitaciones.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N

        huespedes2.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        huespedes2.setText("nº camas:");

        huecoCamas.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N

        huespedes3.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        huespedes3.setText("nº baños:");

        huecoBaños.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N

        botonCasa.setText("Casa");
        botonCasa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonCasaActionPerformed(evt);
            }
        });

        botonApartamento.setText("Apartamento");
        botonApartamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonApartamentoActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel4.setText("Precio/noche:");

        huecoPrecio.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        jLabel5.setText("Servicios(delimiatar con ,): ");

        botonSubirFoto.setFont(new java.awt.Font("Segoe Print", 0, 12)); // NOI18N
        botonSubirFoto.setText("Subir Foto");
        botonSubirFoto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonSubirFotoActionPerformed(evt);
            }
        });

        botonRegistro.setText("REGISTRAR CASA");
        botonRegistro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegistroActionPerformed(evt);
            }
        });

        botonAtras.setText("Atrás");
        botonAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAtrasActionPerformed(evt);
            }
        });

        huecoCiudad.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N

        huespedes4.setFont(new java.awt.Font("Segoe Print", 0, 14)); // NOI18N
        huespedes4.setText("Ciudad:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(103, 103, 103)
                                .addComponent(huecoDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(49, 49, 49))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(huespedes4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(huecoCiudad, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(100, 100, 100)))
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(huecoServicios, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 20, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(botonAtras)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(239, 239, 239))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(huespedes2)
                                .addGap(18, 18, 18)
                                .addComponent(huecoCamas, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(102, 102, 102)
                                .addComponent(botonSubirFoto)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(huespedes)
                                        .addGap(18, 18, 18)
                                        .addComponent(huecoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(huespedes1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(huecoHabitaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(6, 6, 6)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(huecoFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 453, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(huecoTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(botonCasa)
                                .addGap(18, 18, 18)
                                .addComponent(botonApartamento))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(23, 23, 23)
                                .addComponent(jLabel3))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(huecoPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(huespedes3)
                                        .addGap(18, 18, 18)
                                        .addComponent(huecoBaños, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(185, 185, 185)
                .addComponent(botonRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(37, 37, 37))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(botonAtras)
                                .addGap(18, 18, 18)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(botonCasa)
                                    .addComponent(botonApartamento))
                                .addGap(54, 54, 54)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(huecoServicios, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(huecoTitulo))
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(huecoDireccion, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3))
                                .addGap(27, 27, 27)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(huecoCiudad, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(huespedes4))))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(huecoFoto, javax.swing.GroupLayout.PREFERRED_SIZE, 228, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(100, 100, 100)
                                .addComponent(botonSubirFoto))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(huecoHuespedes, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(huespedes))
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(huespedes1)
                                    .addComponent(huecoHabitaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(huespedes2)
                                    .addComponent(huecoCamas, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(huespedes3)
                                    .addComponent(huecoBaños, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(huecoPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(8, 8, 8)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(botonRegistro)
                .addGap(50, 50, 50))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void huecoTituloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_huecoTituloActionPerformed
        
    }//GEN-LAST:event_huecoTituloActionPerformed

    private void botonCasaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonCasaActionPerformed
       
        
    }//GEN-LAST:event_botonCasaActionPerformed

    private void botonApartamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonApartamentoActionPerformed
         
    }//GEN-LAST:event_botonApartamentoActionPerformed

    private void botonSubirFotoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonSubirFotoActionPerformed
          JFileChooser fileChooser = new JFileChooser();
    // Filtrar solo los archivos de imagen
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Archivos de imagen", "jpg", "jpeg", "png", "gif");
    fileChooser.setFileFilter(filter);
    int result = fileChooser.showOpenDialog(this); // "this" se refiere al JFrame actual
    
    if (result == JFileChooser.APPROVE_OPTION) {
        File selectedFile = fileChooser.getSelectedFile();
        rutaFoto = selectedFile.getAbsolutePath(); 
        try {
            // Leer la imagen seleccionada como ImageIcon
            ImageIcon imageIcon = new ImageIcon(selectedFile.getPath());
            // Escalar la imagen para que quepa en el JLabel
            Image scaledImage = imageIcon.getImage().getScaledInstance(huecoFoto.getWidth(), huecoFoto.getHeight(), Image.SCALE_SMOOTH);
            // Establecer la imagen en el JLabel
            huecoFoto.setIcon(new ImageIcon(scaledImage));
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al cargar la imagen", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    }//GEN-LAST:event_botonSubirFotoActionPerformed

    
    public String getRutaFoto() {
        return rutaFoto;
    }
    private void botonRegistroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegistroActionPerformed
        //Sacamos los datos de cada JTextField
        
      String titulo = huecoTitulo.getText();
      String ciudad = huecoCiudad.getText();
      String direccion = huecoDireccion.getText();
      int huespedes = Integer.parseInt(huecoHuespedes.getText());
      int habitaciones = Integer.parseInt(huecoHabitaciones.getText()); // Utiliza el JTextField correspondiente
      int camas = Integer.parseInt(huecoCamas.getText());
      int baños = Integer.parseInt(huecoBaños.getText()); // Utiliza el JTextField correspondiente
      double precio = Double.parseDouble(huecoPrecio.getText());
      String propiedad = "";
      String serviciosTexto = huecoServicios.getText();
      
      String foto = rutaFoto;
 
      String[] serviciosArray = serviciosTexto.split(", ");
      ArrayList<String> servicios = new ArrayList<>();
      for (String servicio : serviciosArray) {
        servicios.add(servicio);
     }
      
      // Tipo de inmueble:
     if (botonCasa.isSelected()) {
        propiedad = "Casa";
     } else {
        propiedad = "Apartamento";
     }
     
     //Creación de la instancia de la clase inmueble con los datos
     Inmueble inmueble = new Inmueble(titulo, ciudad, direccion, huespedes, habitaciones, camas, baños, propiedad,servicios, foto, precio,Login.anfitrionActual);

     //Se añaden los inmuebles al ArrayList inmueble
     UtilInmueble.inmuebles.add(inmueble);
     
     //Guardar los datos en el achivo
     UtilInmueble.guardarInmuebles();
     
     //Una vez registrada la casa volvemos a la página inicial
     dispose();
     vueltaIni.setVisible(true);
     
    }//GEN-LAST:event_botonRegistroActionPerformed

    private void botonAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAtrasActionPerformed
        dispose();
        vueltaIni.setVisible(true);
    }//GEN-LAST:event_botonAtrasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CasaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CasaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CasaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CasaAnfitrion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CasaAnfitrion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton botonApartamento;
    private javax.swing.JButton botonAtras;
    private javax.swing.JRadioButton botonCasa;
    private javax.swing.JButton botonRegistro;
    private javax.swing.JButton botonSubirFoto;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.JTextField huecoBaños;
    private javax.swing.JTextField huecoCamas;
    private javax.swing.JTextField huecoCiudad;
    private javax.swing.JTextField huecoDireccion;
    private javax.swing.JLabel huecoFoto;
    private javax.swing.JTextField huecoHabitaciones;
    private javax.swing.JTextField huecoHuespedes;
    private javax.swing.JTextField huecoPrecio;
    private javax.swing.JTextField huecoServicios;
    private javax.swing.JTextField huecoTitulo;
    private javax.swing.JLabel huespedes;
    private javax.swing.JLabel huespedes1;
    private javax.swing.JLabel huespedes2;
    private javax.swing.JLabel huespedes3;
    private javax.swing.JLabel huespedes4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
