

package com.mycompany.javabnb.interfaces;

import com.mycompany.javabnb.Particular;
import com.mycompany.javabnb.UtilRegistro;
import java.awt.Color;
import java.util.Date;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;



/**
 *Esta clase representa una interfaz de registro de clientes
 * @author Blanquito
 */
public class RegistroCliente extends javax.swing.JFrame {



    /**
     * Crea una nueva interfaz de registro de clientes
     */
    public RegistroCliente() {
        initComponents();
        getContentPane().setBackground(new Color(255, 102, 102));
        ImageIcon icono = new ImageIcon("C:\\Users\\Blanquito\\Desktop\\JavaBnB\\src\\main\\java\\com\\mycompany\\javabnb\\imagenes\\logoJava.png"); // Reemplaza "ruta/de/la/imagen.jpg" con la ruta de tu imagen
        logo.setIcon(icono);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        logo = new javax.swing.JLabel();
        EsloganRegistro = new javax.swing.JLabel();
        labelNombre = new javax.swing.JLabel();
        huecoNombre = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        huecoDNI = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        huecoCorreo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        huecoClave = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        huecoTelf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        huecoTarjeta = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        botonAtras = new javax.swing.JToggleButton();
        fechaSelect = new com.toedter.calendar.JDateChooser();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 102, 102));

        EsloganRegistro.setFont(new java.awt.Font("Lucida Console", 1, 18)); // NOI18N
        EsloganRegistro.setText("REGÍSTRATE GRATIS");

        labelNombre.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        labelNombre.setText("Nombre:");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel1.setText("DNI:");

        huecoDNI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                huecoDNIActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel2.setText("Correo:");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel3.setText("Clave:");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel4.setText("Teléfono:");

        huecoTelf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                huecoTelfActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel5.setText("Número de tarjeta: ");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jLabel6.setText("Fecha de caducidad tarjeta: ");

        botonAtras.setFont(new java.awt.Font("Segoe UI Black", 3, 12)); // NOI18N
        botonAtras.setText("Atrás");
        botonAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAtrasActionPerformed(evt);
            }
        });

        jButton1.setBackground(java.awt.Color.green);
        jButton1.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        jButton1.setText("Registrarse");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonRegistro(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(673, 673, 673))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(55, 55, 55)
                                    .addComponent(labelNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(45, 45, 45)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(botonAtras)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(huecoDNI, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(huecoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(51, 51, 51)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(EsloganRegistro)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(33, 33, 33)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel5)
                                                .addGap(7, 7, 7)
                                                .addComponent(huecoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel4)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(huecoTelf, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                                .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(huecoClave, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(huecoCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(fechaSelect, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(274, 274, 274)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(EsloganRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(botonAtras))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(huecoTelf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(huecoNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelNombre))))
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(huecoTarjeta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(huecoDNI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(huecoCorreo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2)
                        .addComponent(jLabel6))
                    .addComponent(fechaSelect, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(huecoClave, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jButton1)
                .addGap(32, 32, 32))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void huecoDNIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_huecoDNIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_huecoDNIActionPerformed

    private void huecoTelfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_huecoTelfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_huecoTelfActionPerformed

    /**
     * Es un evento, si se pulsa el botón te lleva a la interfaz Inicio
     * @param evt 
     */
    private void botonAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAtrasActionPerformed
       Inicio inicio = new Inicio();
       inicio.setVisible(true);
       dispose();
    }//GEN-LAST:event_botonAtrasActionPerformed

    /**
     * Es un evento, se usa el botón para guardar los campos de registro 
     * @param evt Si las credenciales introducidas son correctas se genera una interfaz de InicioParticular
     */
    private void BotonRegistro(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonRegistro
        // Sacamos los datos de la clase cliente
    
    String nombre = huecoNombre.getText();
    String dni = huecoDNI.getText();
    int telefono = Integer.parseInt(huecoTelf.getText());
    String correo = huecoCorreo.getText();
    String clave = huecoClave.getText();
    Long numTarjeta = null;
    try {
        String textoTarjeta = huecoTarjeta.getText();
        numTarjeta = Long.parseLong(textoTarjeta);
    } catch (NumberFormatException e) {
        // Manejar la situación cuando el texto no es un número long válido
        System.err.println("Error: El texto en el campo de tarjeta no es un número válido");
        e.printStackTrace();
        return; // Salir del método si el número de tarjeta no es válido
    }

    Date fechaCad = fechaSelect.getDate();
    Date date = new Date();
    if (fechaCad == null || fechaCad.compareTo(date) <= 0) {
        JOptionPane.showMessageDialog(null, "La fecha de caducidad de la tarjeta debe ser incorrecta", "Caducidad error", JOptionPane.WARNING_MESSAGE);
        return; // Salir del método si la fecha de caducidad es incorrecta
    }

    boolean VIP = false;

    boolean correoRegistrado = UtilRegistro.correoExiste(correo);
    boolean DNIRegistrado = UtilRegistro.DNIExiste(dni);

    // Si el correo o DNI ya está registrado, detener el proceso de registro
    if (correoRegistrado || DNIRegistrado) {
        return; // Salir del método sin continuar con el registro
    }

    // Creamos la instancia de la clase particular
    Particular particular = new Particular(nombre, dni, telefono, correo, clave, numTarjeta, fechaCad, VIP);

    // Guardamos los datos de los clientes en su array de la clase Util
    UtilRegistro.particulares.add(particular);

    // Ejecutamos el método de la clase particular para guardar los datos del array serializados en un archivo
    UtilRegistro.guardarParticulares();

    dispose();
    Login IniParticular = new Login();
    IniParticular.setVisible(true);
        
    }//GEN-LAST:event_BotonRegistro

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegistroCliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RegistroCliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel EsloganRegistro;
    private javax.swing.JToggleButton botonAtras;
    private com.toedter.calendar.JDateChooser fechaSelect;
    private javax.swing.JTextField huecoClave;
    private javax.swing.JTextField huecoCorreo;
    private javax.swing.JTextField huecoDNI;
    private javax.swing.JTextField huecoNombre;
    private javax.swing.JTextField huecoTarjeta;
    private javax.swing.JTextField huecoTelf;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JLabel logo;
    // End of variables declaration//GEN-END:variables
}
